A Pen created at CodePen.io. You can find this one at http://codepen.io/shivasurya/pen/FatiB.

 jQuery Animated Number Counter From Zero To Value - Javascript Animation 